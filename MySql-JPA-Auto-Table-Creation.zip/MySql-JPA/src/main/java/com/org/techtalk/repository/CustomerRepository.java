package com.org.techtalk.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.org.techtalk.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, String>{

	
	Optional<Customer> findAllLevelTemplateById(String customerId); 
	
	Optional<Customer> findAllLevelById(String customerId); 
	

}
