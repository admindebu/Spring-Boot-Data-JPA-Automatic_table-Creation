package com.org.techtalk.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data

@Entity
//@Table(name = "Customer")
public class Customer {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
   // @Column(name = "id", unique = true, nullable = false)
	private String id; // DB UUID
	private String name;
	private String code;
	private String contactNumber;
	private String contractNumber;
	private String email;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name = "customerId")
	private List<CustomerTemplate> customerTemplate;

	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name = "customerId")
	private List<History> history;
}
