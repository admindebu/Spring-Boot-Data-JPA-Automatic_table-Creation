package com.org.techtalk.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.org.techtalk.entity.CustomerLevel;
import com.org.techtalk.repository.CustomerLevelRespository;

@Service
public class CustomerLevelService {


	@Autowired
	private CustomerLevelRespository customerLevelRespository;
	
	@Transactional
	public CustomerLevel save(CustomerLevel customerLevel) {
		return customerLevelRespository.save(customerLevel);
	}
	
	@Transactional
	public Optional<CustomerLevel> findLevelById(String levelId) {
		return customerLevelRespository.findById(levelId);
	}
}
