package com.org.techtalk.entity;

import java.util.UUID;

import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class EntityWithUUID {

	@Id
	//@Type(type = "mysql-uuid")
	private UUID id;

	public EntityWithUUID() {
		this.id = UUID.randomUUID();
	}

}
