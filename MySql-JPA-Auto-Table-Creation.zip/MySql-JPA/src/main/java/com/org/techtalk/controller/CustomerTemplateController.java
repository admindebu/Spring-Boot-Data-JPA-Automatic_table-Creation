package com.org.techtalk.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.techtalk.entity.CustomerTemplate;
import com.org.techtalk.service.CustomerTemplateService;

@RestController
@RequestMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class CustomerTemplateController {

	@Autowired
	private CustomerTemplateService customerTemplateService;

	@PostMapping(value = "/api/v1/leveltemplate", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CustomerTemplate> saveLevelTemplate(@RequestBody CustomerTemplate customerTemplate) {

		return new ResponseEntity<>(customerTemplateService.save(customerTemplate), HttpStatus.OK);

	}

	@GetMapping(value = "/api/leveltemplate/{tmepId}")
	public ResponseEntity<Optional<CustomerTemplate>> findOneLevelTemplate(@PathVariable String tmepId) {

		return new ResponseEntity<>(customerTemplateService.findById(tmepId), HttpStatus.OK);

	}

}
