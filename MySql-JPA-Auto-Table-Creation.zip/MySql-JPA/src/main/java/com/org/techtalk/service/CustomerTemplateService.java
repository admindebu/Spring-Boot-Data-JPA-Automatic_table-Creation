package com.org.techtalk.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.org.techtalk.entity.CustomerTemplate;
import com.org.techtalk.repository.CustomerTemplateRepository;

@Service
public class CustomerTemplateService {

	
	@Autowired
	private CustomerTemplateRepository customerTemplateRepository;
	
	@Transactional
	public CustomerTemplate save(CustomerTemplate customerTemplate) {
		return customerTemplateRepository.save(customerTemplate);
	}

	@Transactional
	public Optional<CustomerTemplate> findById(String tmepId) {
		return customerTemplateRepository.findById(tmepId);
	}
	
	
	
}
