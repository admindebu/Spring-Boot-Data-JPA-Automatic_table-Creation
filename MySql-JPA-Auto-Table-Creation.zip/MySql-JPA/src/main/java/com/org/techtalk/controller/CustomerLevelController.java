package com.org.techtalk.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.techtalk.entity.CustomerLevel;
import com.org.techtalk.service.CustomerLevelService;

@RestController
@RequestMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class CustomerLevelController {

	
	@Autowired
	private CustomerLevelService customerLevelService;
	
	@PostMapping(value = "/api/v1/cust-level", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CustomerLevel> saveClient(@RequestBody CustomerLevel customerLevel) {

		return new ResponseEntity<>(customerLevelService.save(customerLevel), HttpStatus.OK);

	}

	@GetMapping(value = "/api/v1/cms/cust-level/{levelId}")
	public ResponseEntity<Optional<CustomerLevel>> findOneLevel(@PathVariable String levelId) {

		return new ResponseEntity<>(customerLevelService.findLevelById(levelId), HttpStatus.OK);

	}
	
}




	