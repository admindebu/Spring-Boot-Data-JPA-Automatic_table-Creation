package com.org.techtalk.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data

@Entity
public class History {

	@Id
	private String id; // DB UUID
	private String action;
	private String details;
	private String updatedBy;
	private Date updatedAt;

	private String customerId; // DB UUID	
}
