package com.org.techtalk.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.org.techtalk.entity.CustomerTemplate;

@Repository
public interface CustomerTemplateRepository extends JpaRepository<CustomerTemplate, String>{

}
