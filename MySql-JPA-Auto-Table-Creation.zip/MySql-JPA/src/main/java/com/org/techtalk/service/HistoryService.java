package com.org.techtalk.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.org.techtalk.entity.History;
import com.org.techtalk.repository.HistoryRespository;

@Service
public class HistoryService {

	@Autowired
	private HistoryRespository historyRespository;

	@Transactional
	public History save(History history) {
		return historyRespository.save(history);
	}

	@Transactional
	public Optional<History> findById(String historyId) {
		return historyRespository.findById(historyId);
	}

}
